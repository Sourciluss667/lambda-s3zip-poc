"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.URL_EXPIRE_TIME = exports.UPLOAD_BUCKET_NAME = void 0;
exports.UPLOAD_BUCKET_NAME = "sourciluss-storage";
exports.URL_EXPIRE_TIME = 5 * 60;
