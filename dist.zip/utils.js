"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSignedUrl = exports.streamToZipInS3 = exports.validation = exports.result = void 0;
var aws_sdk_1 = __importDefault(require("aws-sdk"));
var archiver_1 = __importDefault(require("archiver"));
var stream_1 = __importDefault(require("stream"));
var constants_1 = require("./constants");
// Uncomment this when you launch in local
// AWS.config.update({
//   region: 'eu-west-3',
//   credentials: new AWS.Credentials('AKIARVHUEGZ57TKQIV6R', 'UdkAhb/cQFV/e8ymX0OrA1dWfJAIFPuxySk0ez18'),
// });
var S3 = new aws_sdk_1.default.S3({
    apiVersion: '2006-03-01',
    signatureVersion: 'v4',
    httpOptions: {
        timeout: 300000
    }
});
var result = function (code, message) {
    return {
        statusCode: code,
        body: JSON.stringify({
            message: message
        })
    };
};
exports.result = result;
var validation = function (event) {
    var files = event.files;
    if (files.length == 0) {
        console.log('No files to zip');
        return {
            valid: false,
            result: (0, exports.result)(404, 'No files to download'),
        };
    }
    return {
        valid: true,
    };
};
exports.validation = validation;
var streamToZipInS3 = function (files, zipFilePath) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, new Promise(function (resolve, reject) { return __awaiter(void 0, void 0, void 0, function () {
                    var zipStream, archive, _i, files_1, file;
                    return __generator(this, function (_a) {
                        zipStream = streamTo(constants_1.UPLOAD_BUCKET_NAME, zipFilePath, resolve);
                        zipStream.on('error', reject);
                        archive = (0, archiver_1.default)('zip');
                        archive.on("error", function (error) {
                            console.error(error);
                            throw new Error(error.message);
                        });
                        archive.pipe(zipStream);
                        for (_i = 0, files_1 = files; _i < files_1.length; _i++) {
                            file = files_1[_i];
                            archive.append(getStream(constants_1.UPLOAD_BUCKET_NAME, file.path), {
                                name: file.name
                            });
                        }
                        archive.finalize();
                        return [2 /*return*/];
                    });
                }); })
                    .catch(function (err) {
                    console.log(err);
                    throw new Error(err);
                })];
            case 1:
                _a.sent();
                return [2 /*return*/];
        }
    });
}); };
exports.streamToZipInS3 = streamToZipInS3;
var streamTo = function (bucket, key, resolve) {
    var passthrough = new stream_1.default.PassThrough();
    S3.upload({
        Bucket: bucket,
        Key: key,
        Body: passthrough,
        ContentType: "application/zip",
        ServerSideEncryption: "AES256"
    }, function (error, data) {
        if (error) {
            console.error('Error while uploading zip');
            throw new Error(error.message);
        }
        console.log('Zip uploaded');
        resolve(data);
    }).on("httpUploadProgress", function (progress) {
        console.log(progress);
    });
    return passthrough;
};
var getStream = function (bucket, key) {
    var streamCreated = false;
    var passThroughStream = new stream_1.default.PassThrough();
    passThroughStream.on("newListener", function (event) {
        if (!streamCreated && event == "data") {
            var s3Stream = S3
                .getObject({ Bucket: bucket, Key: key })
                .createReadStream();
            s3Stream
                .on("error", function (err) { return passThroughStream.emit("error", err); })
                .pipe(passThroughStream);
            streamCreated = true;
        }
    });
    return passThroughStream;
};
var getSignedUrl = function (bucket, key, expires, downloadFilename) { return __awaiter(void 0, void 0, void 0, function () {
    var exists, params, url;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, objectExists(bucket, key)];
            case 1:
                exists = _a.sent();
                if (!exists) {
                    console.info("Object " + bucket + "/" + key + " does not exists");
                    return [2 /*return*/, null];
                }
                params = {
                    Bucket: bucket,
                    Key: key,
                    Expires: expires,
                };
                if (downloadFilename) {
                    params.ResponseContentDisposition = "inline; filename=\"" + encodeURIComponent(downloadFilename) + "\"";
                }
                try {
                    url = S3.getSignedUrl('getObject', params);
                    return [2 /*return*/, url];
                }
                catch (err) {
                    console.error("Unable to get URL for " + bucket + "/" + key, err);
                    return [2 /*return*/, null];
                }
                return [2 /*return*/];
        }
    });
}); };
exports.getSignedUrl = getSignedUrl;
var objectExists = function (bucket, key) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        return [2 /*return*/, S3
                .headObject({
                Bucket: bucket,
                Key: key,
            })
                .promise()
                .then(function () { return true; }, function (err) {
                if (err.code === 'NotFound') {
                    return false;
                }
                throw err;
            })];
    });
}); };
